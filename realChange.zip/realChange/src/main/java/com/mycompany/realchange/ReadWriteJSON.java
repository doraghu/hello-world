/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.realchange;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;


/**
 *
 * @author guest_fta42xy
 */
public class ReadWriteJSON {
    
    public static void main(String ... args) throws IOException{
        
        String jsonData = "";
        BufferedReader br = null;
		try {
			String line;
                        
                       //String propFileName = "resources/company.json";                        
                                      
			br = new BufferedReader(new FileReader("R:\\Primary\\explorer\\realChange\\src\\main\\java\\resources\\company.json"));
			while ((line = br.readLine()) != null) {
				jsonData += line + "\n";
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
                
                 String jsonData2 = "";
                try( BufferedReader br2 = new BufferedReader(new FileReader("R:\\Primary\\explorer\\realChange\\src\\main\\java\\resources\\company.json") )) {                    
                    String line2;                    
                    while ((line2 = br2.readLine()) != null) {
				jsonData2 += line2 + "\n";
		    }
                    
                }
                
		// System.out.println("File Content: \n" + jsonData);
		JSONObject obj = new JSONObject(jsonData2);
                
               	System.out.println("Name: " + obj.get("Name"));
		System.out.println("Owner: " + obj.get("Owner"));
                JSONArray jsonArry = (JSONArray) obj.get("Employee List");
		System.out.println("Employee List: " + obj.get("Employee List") );
                
                Iterator<Object> iterator = jsonArry.iterator();
                
                 while (iterator.hasNext()) {
                    System.out.println(iterator.next());
                }
                
               
	} 
    
    
}
